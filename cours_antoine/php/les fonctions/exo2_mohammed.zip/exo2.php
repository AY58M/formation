<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fonctions</title>
</head>

<body>

    <h2>Exercices supplémentaires PHP - Fonctions</h2>

    <h3>Exercice 1 - Fonction avec typage et contrôle</h3>

    <form action="" method="POST">
        <input placeholder="Prénom" type="text" name="prenom">
        <input type="submit" value="Envoyer">
    </form>

    <?php

    function direBonjour($prenom)
    {

        if ($prenom === "") {
            echo "Bonjour invité";
        } else {
            echo "Bonjour $prenom";
        }
    }

    if (isset($_POST["prenom"])) {

        $prenom = $_POST["prenom"];
        echo direBonjour($prenom);
    }

    echo "<h3>Exercice 2 - Fonction de calcul avec valeur par défaut</h3>";

    ?>


    <form action="" method="post">
        <input type="text" placeholder="Prix HT" name="prixht"><br>
        <input type="text" placeholder="TVA" name="tva"><br>
        <input type="submit" value="Send">
    </form>


    <?php

    function calculerPrixTTC($prixHT, $TVA = 0.20)
    {
        return round($prixHT + $prixHT * $TVA, 2);
    }

    if (isset($_POST['prixht'], $_POST['tva'])) {

        $prixHT = (float) $_POST['prixht'];
        $TVA = (float) $_POST['tva'] / 100;

        if ($TVA == 0) {
            echo "Le prix TCC est : " . calculerPrixTTC($prixHT) . " €" . "<br>";
        } else {
            echo "Le prix TCC est : " . calculerPrixTTC($prixHT, $TVA) . " €" . "<br>";
        }
    }

    ?>

    <h3>Exercice 3 – Fonction qui transforme un tableau</h3>
    <p>Créer une fonction appliquerReduction qui prend un tableau de prix et un pourcentage de réduction. La
        fonction retourne un nouveau tableau contenant les prix réduits. Exemple : [10, 20, 50] avec 10 % devient
        [9, 18, 45].</p>

    <?php
    function appliquerReduction ( array $prix ,  $reduction) {
        $prixreduit = [];
        foreach ($prix as $p) {
            $prixreduit[] = round($p - ($p * $reduction / 100), 2);
        }
    
    return $prixreduit;

    }





    ?>

</body>

</html>